module Constants
  WIDTH = 1280
  HEIGHT = 720
  SPRITE_SIZE = 160
  GRAVITY = -1
  JUMP_FORCE = -27
  SNAKE_SPEED = 14
end

module State
  START = 0
  RUNNING = 1
  GAME_OVER = 2
end

def init
  
end

def tick args
  
end